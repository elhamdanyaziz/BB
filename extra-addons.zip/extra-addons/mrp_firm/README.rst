.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
    :alt: License: AGPL-3

MRP - BoM notes
===============

This module creates in BoM a new field to add notes , add code in tree view


Bug Tracker
===========






Contributors
------------

* Smartaps Conseil
* FIRM


Maintainer
----------

